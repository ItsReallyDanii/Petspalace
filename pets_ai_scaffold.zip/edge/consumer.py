"""Stub event consumers for litter/feeder and playroom alerts.

In a production system this module would connect to a NATS (or MQTT) broker
and subscribe to the channels defined in ``contracts/asyncapi.yaml``.  Upon
receiving messages it would validate the payloads against the AsyncAPI
schemas, perform any threshold calculations and insert rows into the
``events`` or ``alerts`` tables accordingly.

For the purposes of this scaffold the consumers simply log the incoming
messages.  See ``tests/fixtures/litter_event.json`` and
``tests/fixtures/playroom_alert.json`` for example payloads.
"""

import asyncio
import json
from typing import Any

import nats


async def handle_litter_event(msg: Any) -> None:
    """Handle events on the ``events.litter.*`` subject."""
    data = json.loads(msg.data.decode())
    subject = msg.subject
    print(f"Received litter event on {subject}: {data}")
    # TODO: validate payload against AsyncAPI schema and persist to DB


async def handle_playroom_alert(msg: Any) -> None:
    """Handle alerts on the ``playroom.alerts.*`` subject."""
    data = json.loads(msg.data.decode())
    subject = msg.subject
    print(f"Received playroom alert on {subject}: {data}")
    # TODO: validate payload against AsyncAPI schema and persist to DB


async def main() -> None:
    """Main entrypoint for the consumer process."""
    nc = await nats.connect("nats://localhost:4222")
    # Subscribe with wildcards; NATS will deliver messages for each subject
    await nc.subscribe("events.litter.*", cb=handle_litter_event)
    await nc.subscribe("playroom.alerts.*", cb=handle_playroom_alert)
    print("Edge consumers are listening for events...")
    try:
        # Keep the connection alive indefinitely
        while True:
            await asyncio.sleep(1)
    except asyncio.CancelledError:
        pass
    finally:
        await nc.drain()


if __name__ == "__main__":
    asyncio.run(main())