"""Simple in-memory database for prototype purposes.

For the purposes of this scaffold, we use a plain in-memory data store
backed by Python dictionaries.  In a production deployment this would be
replaced with a proper Postgres database with SQLAlchemy models and
migrations located under ``infra/migrations``.  Persisted identifiers are
represented as strings for convenience.
"""

from __future__ import annotations

import uuid
from typing import Dict, List, Optional, Tuple

from .models import CreateCaseRequest, CreateCaseResponse, PhotoUploadResponse, SearchCandidate


class InMemoryDB:
    """A minimal database abstraction that stores cases and photos in memory."""

    def __init__(self) -> None:
        # Primary key → case record
        self.cases: Dict[str, dict] = {}
        # Primary key → photo record
        self.photos: Dict[str, dict] = {}

    def create_case(self, data: CreateCaseRequest) -> CreateCaseResponse:
        """Persist a new case and return its identifier."""
        case_id = str(uuid.uuid4())
        self.cases[case_id] = {
            "user_id": data.user_id,
            "type": data.type,
            "species": data.species,
            "geohash6": data.geohash6,
            "consent": data.consent.dict(),
        }
        return CreateCaseResponse(case_id=case_id)

    def add_photo(self, case_id: str, filename: str, view: Optional[str]) -> PhotoUploadResponse:
        """Persist a photo associated with a case."""
        photo_id = str(uuid.uuid4())
        self.photos[photo_id] = {
            "case_id": case_id,
            "filename": filename,
            "view": view,
        }
        return PhotoUploadResponse(photo_id=photo_id)

    def get_case(self, case_id: str) -> Optional[dict]:
        """Retrieve a case by ID or return ``None``."""
        return self.cases.get(case_id)

    def list_photos(self, case_id: str) -> List[dict]:
        """List photos for a given case."""
        return [photo for photo in self.photos.values() if photo["case_id"] == case_id]


def load_search_candidates(fixture_path: str) -> List[SearchCandidate]:
    """Load deterministic search candidates from a JSON fixture file.

    The fixture is expected to be a list of objects with ``pet_id``, ``score``
    and ``band`` fields.  If the file cannot be read the function returns
    an empty list.
    """
    import json
    try:
        with open(fixture_path, "r", encoding="utf-8") as fp:
            raw = json.load(fp)
        return [SearchCandidate(**item) for item in raw]
    except Exception:
        return []