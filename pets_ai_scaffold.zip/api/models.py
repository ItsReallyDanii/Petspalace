"""Pydantic models derived from the OpenAPI specification.

These models mirror the data structures defined in ``contracts/openapi.yaml`` and
are used by the FastAPI handlers for request validation and response
serialization.  Keeping the models in one place makes it easier to
regenerate them when the contract changes.
"""

from __future__ import annotations

from typing import List, Optional
from pydantic import BaseModel, Field, HttpUrl, root_validator


class Consent(BaseModel):
    """Consent flags controlling privacy behaviour."""

    shareVectors: bool = Field(..., description="Whether embeddings may be shared with other cases")
    sharePhotos: bool = Field(..., description="Whether photos may be shared with other cases")


class CreateCaseRequest(BaseModel):
    """Request model for creating a new case."""

    user_id: str = Field(..., description="Identifier of the owner submitting the case")
    type: str = Field(..., description="Nature of the case (lost/found)")
    species: str = Field(..., description="Species of animal (e.g. dog, cat)")
    geohash6: str = Field(..., description="Approximate location encoded as a six‑character geohash")
    consent: Consent


class CreateCaseResponse(BaseModel):
    """Response model for case creation."""

    case_id: str


class PhotoUploadResponse(BaseModel):
    """Response model for photo uploads."""

    photo_id: str


class SearchRequest(BaseModel):
    """Request model for running a search."""

    case_id: str = Field(..., description="Identifier of the case to search against")
    top_k: Optional[int] = Field(10, description="Number of candidates to return", ge=1)


class SearchCandidate(BaseModel):
    """Candidate result item returned from a search."""

    pet_id: str
    score: float
    band: str


class SearchResponse(BaseModel):
    """Response model for search results."""

    candidates: List[SearchCandidate]