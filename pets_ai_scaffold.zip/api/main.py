"""FastAPI application for the Pets × AI HTTP API.

This module wires together request/response models, a simple in-memory
database and deterministic search fixtures to satisfy the core
functionality described in the project README.  The endpoints defined
here must conform to the shapes specified in ``contracts/openapi.yaml``.

You can run the development server from the repository root:

    uvicorn api.main:app --reload
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import List

from fastapi import Depends, FastAPI, File, Form, HTTPException, UploadFile, status
from fastapi.responses import JSONResponse, PlainTextResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseSettings

from .models import (
    CreateCaseRequest,
    CreateCaseResponse,
    PhotoUploadResponse,
    SearchRequest,
    SearchResponse,
    SearchCandidate,
)
from .database import InMemoryDB, load_search_candidates


class Settings(BaseSettings):
    """Application configuration settings.

    In a real service these values would be loaded from environment
    variables or configuration files.  Default values are provided for
    local development.
    """

    search_fixture: str = str(Path(__file__).resolve().parent.parent / "tests/fixtures/search_candidates.json")

    class Config:
        env_prefix = "PETS_"


def get_settings() -> Settings:
    return Settings()


def get_db() -> InMemoryDB:
    """Dependency injector for the in-memory database."""
    # In a real service you might use a connection pool or sessionmaker here.
    return app.state.db


app = FastAPI(title="Pets × AI API", version="1.0.0")

# Initialise shared state
app.state.db = InMemoryDB()
app.state.settings = Settings()

# Enable CORS for development front‑ends (e.g. Next.js on localhost:3000)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000", "http://127.0.0.1:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.post("/v1/cases", response_model=CreateCaseResponse, status_code=status.HTTP_201_CREATED)
def create_case(request: CreateCaseRequest, db: InMemoryDB = Depends(get_db)) -> CreateCaseResponse:
    """Create a new lost‑pet case."""
    return db.create_case(request)


@app.post(
    "/v1/cases/{case_id}/photos",
    response_model=PhotoUploadResponse,
    status_code=status.HTTP_201_CREATED,
)
async def upload_photo(
    case_id: str,
    file: UploadFile = File(...),
    view: str | None = Form(None),
    db: InMemoryDB = Depends(get_db),
) -> PhotoUploadResponse:
    """Upload a photo for an existing case.

    For this scaffold the file bytes are not persisted; only the file
    metadata and association with the case are stored in memory.  The
    contents of the upload are discarded.
    """
    # Verify the case exists
    if db.get_case(case_id) is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Case not found")
    # Read and discard the content to avoid unsaved file warnings
    await file.read()
    return db.add_photo(case_id, filename=file.filename, view=view)


@app.post("/v1/search", response_model=SearchResponse)
def search(
    request: SearchRequest,
    settings: Settings = Depends(get_settings),
) -> SearchResponse:
    """Run a deterministic visual search and return the top‑K candidates.

    Candidates are loaded from a fixture file at startup.  The ``top_k``
    parameter controls the number of returned items and defaults to 10.
    """
    fixture_path = settings.search_fixture
    candidates: List[SearchCandidate] = load_search_candidates(fixture_path)
    # If the fixture is not present we return an empty list
    k = request.top_k or 10
    return SearchResponse(candidates=candidates[:k])


@app.get("/docs/openapi.yaml", response_class=PlainTextResponse)
def serve_openapi_yaml() -> str:
    """Serve the raw OpenAPI contract for easy access from the UI/documentation."""
    contract_path = Path(__file__).resolve().parents[1] / "contracts/openapi.yaml"
    return contract_path.read_text(encoding="utf-8")


@app.get("/docs/asyncapi.yaml", response_class=PlainTextResponse)
def serve_asyncapi_yaml() -> str:
    """Serve the raw AsyncAPI contract."""
    contract_path = Path(__file__).resolve().parents[1] / "contracts/asyncapi.yaml"
    return contract_path.read_text(encoding="utf-8")


@app.get("/alerts.json")
def get_alerts() -> JSONResponse:
    """Return a list of recent alerts.

    This endpoint is a placeholder used by the web front‑end to poll for
    new alerts.  In a full implementation it would query the database for
    recent alert entries.  For now it always returns an empty list.
    """
    return JSONResponse({"alerts": []})


@app.on_event("startup")
def on_startup() -> None:
    """Load deterministic search candidates into memory on startup."""
    # Preload the fixtures so they are hot in memory.  We don't store them in
    # state to keep the example simple; the loader caches results anyway.
    settings: Settings = app.state.settings
    _ = load_search_candidates(settings.search_fixture)