"use client";

import { useEffect, useState } from "react";

interface Alert {
  id: string;
  pet_id: string;
  room_id?: string;
  kind: string;
  severity: string;
  state: string;
  evidence_url?: string;
  ts: string;
}

export default function AlertsPage() {
  const [alerts, setAlerts] = useState<Alert[]>([]);

  // Poll the API periodically for alerts (placeholder implementation)
  useEffect(() => {
    const interval = setInterval(async () => {
      try {
        const resp = await fetch("/alerts.json");
        if (resp.ok) {
          const data = await resp.json();
          setAlerts(data.alerts || []);
        }
      } catch (err) {
        console.error(err);
      }
    }, 2000);
    return () => clearInterval(interval);
  }, []);

  return (
    <main style={{ padding: "2rem", fontFamily: "sans-serif" }}>
      <h1>Alerts Feed</h1>
      {alerts.length === 0 ? (
        <p>No alerts yet.</p>
      ) : (
        <ul style={{ listStyle: "none", padding: 0 }}>
          {alerts.map((alert) => (
            <li
              key={alert.id}
              style={{
                border: "1px solid #ccc",
                borderRadius: "4px",
                padding: "0.5rem",
                marginBottom: "0.5rem",
              }}
            >
              <strong>{alert.kind}</strong> ({alert.severity}) – {alert.state}
              <br />
              Pet: {alert.pet_id}
              {alert.room_id && <>, Room: {alert.room_id}</>}
              <br />
              <small>{new Date(alert.ts).toLocaleString()}</small>
              {alert.evidence_url && (
                <div>
                  <a href={alert.evidence_url} target="_blank" rel="noopener noreferrer">
                    View clip
                  </a>
                </div>
              )}
            </li>
          ))}
        </ul>
      )}
    </main>
  );
}