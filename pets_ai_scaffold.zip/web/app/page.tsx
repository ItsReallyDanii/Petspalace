"use client";

import Link from "next/link";

export default function Home() {
  return (
    <main style={{ padding: "2rem", fontFamily: "sans-serif" }}>
      <h1>Pets × AI Dashboard</h1>
      <p>
        This Next.js front‑end is part of the Pets × AI monorepo.  It will
        eventually host the lost‑pet search UI, alerts feeds and privacy console.
        At the moment the pages are placeholders.
      </p>
      <nav style={{ display: "flex", gap: "1rem", marginTop: "1.5rem" }}>
        <Link href="/search">Lost‑Pet Search</Link>
        <Link href="/alerts">Alerts</Link>
        <Link href="/privacy">Privacy Console</Link>
      </nav>
    </main>
  );
}