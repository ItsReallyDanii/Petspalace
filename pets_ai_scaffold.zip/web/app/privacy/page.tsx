"use client";

export default function PrivacyConsole() {
  return (
    <main style={{ padding: "2rem", fontFamily: "sans-serif" }}>
      <h1>Privacy Console</h1>
      <p>
        This page will allow users to review their consent flags and export or
        erase their data.  Functionality is not implemented in this scaffold.
      </p>
      <button disabled title="Not yet implemented">
        Export/Erase
      </button>
    </main>
  );
}