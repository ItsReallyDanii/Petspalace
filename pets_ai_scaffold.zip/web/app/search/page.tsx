"use client";

import { useState } from "react";

export default function SearchPage() {
  const [caseId, setCaseId] = useState("");
  const [results, setResults] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  async function handleSearch(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setLoading(true);
    try {
      const resp = await fetch("/v1/search", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ case_id: caseId, top_k: 10 }),
      });
      const data = await resp.json();
      setResults(data.candidates || []);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  }

  return (
    <main style={{ padding: "2rem", fontFamily: "sans-serif" }}>
      <h1>Lost‑Pet Visual Search</h1>
      <form onSubmit={handleSearch} style={{ marginTop: "1rem" }}>
        <label>
          Case ID:
          <input
            type="text"
            value={caseId}
            onChange={(e) => setCaseId(e.target.value)}
            style={{ marginLeft: "0.5rem" }}
          />
        </label>
        <button type="submit" style={{ marginLeft: "1rem" }}>Search</button>
      </form>
      {loading && <p>Searching…</p>}
      {results.length > 0 && (
        <table
          style={{ borderCollapse: "collapse", marginTop: "1rem", width: "100%" }}
        >
          <thead>
            <tr>
              <th style={{ borderBottom: "1px solid #ccc", textAlign: "left" }}>Pet ID</th>
              <th style={{ borderBottom: "1px solid #ccc", textAlign: "left" }}>Score</th>
              <th style={{ borderBottom: "1px solid #ccc", textAlign: "left" }}>Band</th>
            </tr>
          </thead>
          <tbody>
            {results.map((item) => (
              <tr key={item.pet_id}>
                <td style={{ padding: "0.25rem 0" }}>{item.pet_id}</td>
                <td>{item.score.toFixed(2)}</td>
                <td>{item.band}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </main>
  );
}